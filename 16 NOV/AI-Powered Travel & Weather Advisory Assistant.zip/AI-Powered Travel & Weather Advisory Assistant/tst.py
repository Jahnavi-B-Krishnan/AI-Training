from tools.trip_tools import create_trip
from schemas import TripCreate

# Sample trip details
trip = TripCreate(
    employee_id="EMP104",
    destination="Jaipur",
    start_date="2026-11-19",
    end_date="2026-11-21",
    purpose="Client meeting"
)

# Save trip to PostgreSQL
try:
    result = create_trip(trip)

    print("\nTrip created successfully!")
    print("--------------------------------")
    print(f"Trip ID: {result['trip_id']}")
    print(f"Employee ID: {result['employee_id']}")
    print(f"Destination: {result['destination']}")
    print(f"Start Date: {result['start_date']}")
    print(f"End Date: {result['end_date']}")
    print(f"Purpose: {result['purpose']}")
    print(f"Status: {result['status']}")

except Exception as e:
    print("Error creating trip:", e)