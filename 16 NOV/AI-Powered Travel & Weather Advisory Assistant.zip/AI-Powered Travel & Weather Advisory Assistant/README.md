
## Technologies Used

- Python
- FastAPI
- LangChain
- Ollama (Qwen 3.5 – 4B)
- PostgreSQL
- Redis
- Docker
- Open-Meteo API


## Features

- Create and save business trip details.
- Retrieve previously saved trips.
- Check weather forecasts for travel dates.
- Get AI-generated travel and packing suggestions.
- Ask follow-up questions without repeating the destination.
- Maintain separate conversations using session IDs.
- Handle invalid inputs and unavailable weather information.

## Getting Started

 1. Install the required packages

 2. Set up PostgreSQL

 3. Set up Redis

 4. Set up Ollama

 5. Configure the environment

## How It Works

1. The employee creates a trip, and its details are saved in PostgreSQL.
2. When the employee asks a question, the application retrieves the saved trip.
3. The weather tool gets the forecast from Open-Meteo.
4. Redis retrieves the previous conversation for that session.
5. LangChain sends the information to the local Qwen model.
6. The model generates a travel advisory.
7. The new conversation is saved in Redis.

## Testing

The application was tested using FastAPI Swagger UI.

The following scenarios were tested:

- Creating a new trip.
- Retrieving an existing trip.
- Asking questions about the destination's weather.
- Asking follow-up questions using the same session ID.
- Using different session IDs for separate conversations.
- Handling invalid trip details and unavailable forecast dates.


