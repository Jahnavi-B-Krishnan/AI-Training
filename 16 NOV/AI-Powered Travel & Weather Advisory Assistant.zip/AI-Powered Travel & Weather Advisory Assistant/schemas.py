
from pydantic import BaseModel, Field, field_validator, model_validator
from datetime import date


class TripCreate(BaseModel):

    employee_id: str = Field(..., min_length=1)
    destination: str = Field(..., min_length=1)
    start_date: date
    end_date: date
    purpose: str = Field(..., min_length=1)

    @field_validator("employee_id", "destination", "purpose")
    @classmethod
    def validate_text(cls, value):

        value = value.strip()

        if not value:
            raise ValueError("Field cannot be empty")

        return value

    @model_validator(mode="after")
    def validate_dates(self):

        if self.start_date < date.today():
            raise ValueError("Travel start date cannot be in the past")

        if self.end_date < self.start_date:
            raise ValueError("End date cannot be before start date")

        return self


class TripResponse(BaseModel):

    trip_id: int
    employee_id: str
    destination: str
    start_date: date
    end_date: date
    purpose: str
    status: str
