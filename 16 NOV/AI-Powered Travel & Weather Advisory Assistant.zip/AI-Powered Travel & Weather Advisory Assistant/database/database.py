
import psycopg2
import os
from dotenv import load_dotenv

load_dotenv()


def get_connection():
    """
    Connect to PostgreSQL database.
    """

    conn = psycopg2.connect(
        host=os.getenv("DB_HOST"),
        database=os.getenv("DB_NAME"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        port=os.getenv("DB_PORT", "5432")
    )

    return conn


def initialize_database():

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
        CREATE TABLE IF NOT EXISTS trips (
            trip_id SERIAL PRIMARY KEY,
            employee_id VARCHAR(50) NOT NULL,
            destination VARCHAR(100) NOT NULL,
            start_date DATE NOT NULL,
            end_date DATE NOT NULL,
            purpose VARCHAR(255) NOT NULL,
            status VARCHAR(30) DEFAULT 'Planned',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

            CHECK (end_date >= start_date)
        )
    """)

    conn.commit()

    print("Trips table created successfully!")

    cursor.close()
    conn.close()


if __name__ == "__main__":
    initialize_database()
