
from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field

from schemas import TripCreate
from tools.trip_tools import create_trip, get_trip_by_id
from assistant.workflow import run_travel_workflow


app = FastAPI(
    title="AI-Powered Travel & Weather Advisory Assistant",
    description="An AI assistant for business travel planning and weather-based advice.",
    version="1.0.0"
)


# Request model for chat endpoint
class ChatRequest(BaseModel):
    trip_id: int = Field(..., gt=0)
    session_id: str = Field(..., min_length=1)
    question: str = Field(..., min_length=1)

    def clean_inputs(self):
        self.session_id = self.session_id.strip()
        self.question = self.question.strip()

        if not self.session_id:
            raise ValueError("Session ID cannot be empty")

        if not self.question:
            raise ValueError("Question cannot be empty")

        return self


# --------------------------------------------------
# 1. CREATE A NEW TRIP
# --------------------------------------------------

@app.post("/trips", status_code=201)
def create_new_trip(trip: TripCreate):

    try:
        result = create_trip(trip)

        return {
            "message": "Trip created successfully",
            "trip": result
        }

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Unable to create trip: {str(e)}"
        )


# --------------------------------------------------
# 2. RETRIEVE AN EXISTING TRIP
# --------------------------------------------------

@app.get("/trips/{trip_id}")
def retrieve_trip(trip_id: int):

    if trip_id <= 0:
        raise HTTPException(
            status_code=400,
            detail="Trip ID must be a positive integer"
        )

    try:
        trip = get_trip_by_id(trip_id)

        if trip is None:
            raise HTTPException(
                status_code=404,
                detail="Trip not found"
            )

        return {
            "message": "Trip retrieved successfully",
            "trip": trip
        }

    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Unable to retrieve trip: {str(e)}"
        )


# --------------------------------------------------
# 3. ASK THE TRAVEL ASSISTANT
# --------------------------------------------------

@app.post("/chat")
def chat_with_assistant(request: ChatRequest):

    request.clean_inputs()

    try:
        result = run_travel_workflow(
            trip_id=request.trip_id,
            session_id=request.session_id,
            question=request.question
        )

        if "error" in result:
            raise HTTPException(
                status_code=400,
                detail=result["error"]
            )

        return {
            "message": "Assistant response generated successfully",
            "session_id": request.session_id,
            "trip_id": request.trip_id,
            "destination": result["destination"],
            "answer": result["answer"]
        }

    except HTTPException:
        raise

    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Assistant request failed: {str(e)}"
        )


# --------------------------------------------------
# ROOT ENDPOINT
# --------------------------------------------------

@app.get("/")
def home():

    return {
        "message": "Welcome to the Travel & Weather Advisory Assistant API",
        "status": "Running"
    }
