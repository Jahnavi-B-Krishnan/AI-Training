
from database.database import get_connection
from schemas import TripCreate
import psycopg2.extras


def create_trip(trip: TripCreate):
    """
    Insert a new employee trip into PostgreSQL.
    """

    conn = get_connection()

    cursor = conn.cursor(
        cursor_factory=psycopg2.extras.RealDictCursor
    )

    try:

        cursor.execute("""
            INSERT INTO trips
            (
                employee_id,
                destination,
                start_date,
                end_date,
                purpose
            )
            VALUES (%s, %s, %s, %s, %s)
            RETURNING *
        """, (
            trip.employee_id,
            trip.destination,
            trip.start_date,
            trip.end_date,
            trip.purpose
        ))

        result = cursor.fetchone()

        conn.commit()

        return dict(result)

    except Exception as e:

        conn.rollback()
        print("Trip creation failed:", e)
        raise

    finally:

        cursor.close()
        conn.close()


def get_trip_by_id(trip_id: int):
    """
    Retrieve an existing trip using its ID.
    """

    conn = get_connection()

    cursor = conn.cursor(
        cursor_factory=psycopg2.extras.RealDictCursor
    )

    try:

        cursor.execute("""
            SELECT *
            FROM trips
            WHERE trip_id = %s
        """, (trip_id,))

        result = cursor.fetchone()

        if result is None:
            return None

        return dict(result)

    finally:

        cursor.close()
        conn.close()
