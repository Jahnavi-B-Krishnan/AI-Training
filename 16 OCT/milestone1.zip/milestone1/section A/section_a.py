import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

df= pd.read_csv("urban_mobility.csv")
print(df.head())

df['Energy_Per_Km']=df['Energy_Used_kWh']/df['Distance_Km']

print(df[(df['Maintenance_Flag']=='Yes') & (df['Vehicle_Type']=='Electric Van')])

print(df.groupby("Vehicle_Type").agg(Avg_Distance=("Distance_Km", np.mean),Total_Trips=("Trips_Count", np.sum)))
print(np.mean(df["Energy_Used_kWh"]),np.max(df["Energy_Used_kWh"]),np.min(df["Energy_Used_kWh"]))

avg_energy = df.groupby('Vehicle_Type')['Energy_Per_Km'].mean()

plt.bar(avg_energy.index, avg_energy.values)
plt.xlabel("Vehicle Type")
plt.ylabel("Average Energy per Km")
plt.title("Average Energy Consumption by Vehicle Type")
plt.tight_layout()
plt.show()

import json
with open('equipment_events.json') as json_file:
    data = json.load(json_file)
for i in data:
    print(i["event_id"],i["asset"]["type"],i["asset"]["site"])
for x in data:
    if x["temperature"] > 70:
        x.get('actions','No actions recorded')
        print(x)

with open("coastal_monitoring_log.txt") as file:
    txt=file.read()
print("Total words:",len(txt.split()))
txt_lower=txt.lower()

print("Number of times inspection appear:",txt_lower.split().count("inspection"))

with open("coastal_monitoring_log.txt") as f:
    lines=f.readlines()
keywords=['boardwalk','maintenance','wind']
for line in lines:
    if any(word in line.lower() for word in keywords):
        print(line.strip())

