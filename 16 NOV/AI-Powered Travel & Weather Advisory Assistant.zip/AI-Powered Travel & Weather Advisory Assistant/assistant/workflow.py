
import json

from assistant.llm import get_llm
from assistant.memory import add_message, get_recent_history
from tools.trip_tools import get_trip_by_id
from tools.weather_tools import weather_tool

from langchain_core.messages import SystemMessage, HumanMessage, AIMessage


def run_travel_workflow(trip_id: int, session_id: str, question: str):
    """
    Retrieve saved trip details, fetch actual weather,
    use conversation history, and generate a travel advisory.
    """

    # STAGE 1: Retrieve the saved trip from PostgreSQL
    trip = get_trip_by_id(trip_id)

    if trip is None:
        return {"error": f"No trip found with ID {trip_id}."}

    destination = trip["destination"]
    start_date = trip["start_date"].isoformat()
    end_date = trip["end_date"].isoformat()

    # STAGE 2: Retrieve actual weather using the weather tool
    weather_data = weather_tool.invoke({
        "city": destination,
        "start_date": start_date,
        "end_date": end_date
    })

    if isinstance(weather_data, str):
        try:
            weather_data = json.loads(weather_data)
        except json.JSONDecodeError:
            pass

    if isinstance(weather_data, dict) and "error" in weather_data:
        return {
            "error": weather_data["error"],
            "trip": {
                "destination": destination,
                "start_date": start_date,
                "end_date": end_date
            }
        }

    # STAGE 3: Retrieve previous conversation messages from Redis
    history = get_recent_history(session_id)

    messages = [
        SystemMessage(
            content=(
                "You are an AI-powered business travel assistant. "
                "Generate concise, practical travel advice using the "
                "saved trip details and actual weather information supplied. "
                "Never invent weather conditions or forecast values. "
                "If information is missing, clearly state that. "
                "Include a weather summary and 3-4 suitable travel "
                "or packing suggestions."
            )
        )
    ]

    # Add previous conversation context
    for item in history:
        if item["role"] == "user":
            messages.append(HumanMessage(content=item["content"]))
        elif item["role"] == "assistant":
            messages.append(AIMessage(content=item["content"]))

    # Add the current question and factual information
    current_prompt = f"""
    Employee trip details:
    Destination: {destination}
    Travel start date: {start_date}
    Travel end date: {end_date}
    Purpose: {trip["purpose"]}

    Actual weather forecast:
    {json.dumps(weather_data, default=str, indent=2)}

    Employee question:
    {question}

    Answer using the actual forecast and the conversation context.
    """

    messages.append(HumanMessage(content=current_prompt))

    # STAGE 4: Generate the advisory using Qwen
    llm = get_llm()
    response = llm.invoke(messages)

    answer = response.content

    # STAGE 5: Save the conversation in Redis
    add_message(session_id, "user", question)
    add_message(session_id, "assistant", answer)

    return {
        "trip_id": trip_id,
        "destination": destination,
        "weather": weather_data,
        "answer": answer
    }



if __name__ == "__main__":

    session_id = "TEST_SESSION_001"

    print("\n--- FIRST QUESTION ---")

    result1 = run_travel_workflow(
        trip_id=1,
        session_id=session_id,
        question="What weather should I expect for my trip?"
    )

    print("\nAssistant:", result1.get("answer", result1.get("error")))

    print("\n--- FOLLOW-UP QUESTION ---")

    result2 = run_travel_workflow(
        trip_id=1,
        session_id=session_id,
        question="Should I pack an umbrella?"
    )

    print("\nAssistant:", result2.get("answer", result2.get("error")))

    print("\n--- SAVED REDIS HISTORY ---")

    history = get_recent_history(session_id)

    for message in history:
        print(message)


