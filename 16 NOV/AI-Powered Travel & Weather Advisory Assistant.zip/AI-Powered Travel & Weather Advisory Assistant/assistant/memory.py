
import os
import json
import redis
from dotenv import load_dotenv

load_dotenv()

# Redis configuration
REDIS_HOST = os.getenv("REDIS_HOST", "localhost")
REDIS_PORT = int(os.getenv("REDIS_PORT", 6379))
REDIS_DB = int(os.getenv("REDIS_DB", 0))
REDIS_TTL = int(os.getenv("REDIS_TTL", 86400))

# Connect to Redis
redis_client = redis.Redis(
    host=REDIS_HOST,
    port=REDIS_PORT,
    db=REDIS_DB,
    decode_responses=True
)

MAX_MESSAGES = 10


def get_session_key(session_id: str) -> str:
    """Generate a separate Redis key for each conversation session."""

    if not session_id or not session_id.strip():
        raise ValueError("Session ID cannot be empty")

    return f"travel_assistant:session:{session_id}:messages"


def add_message(session_id: str, role: str, content: str):
    """Store a user or assistant message in Redis."""

    if role not in ("user", "assistant"):
        raise ValueError("Role must be user or assistant")

    if not content or not content.strip():
        raise ValueError("Message content cannot be empty")

    key = get_session_key(session_id)

    message = {
        "role": role,
        "content": content
    }

    redis_client.rpush(key, json.dumps(message))

    # Keep only the latest 10 messages
    redis_client.ltrim(key, -MAX_MESSAGES, -1)

    # Expire the session after the configured TTL
    redis_client.expire(key, REDIS_TTL)


def get_recent_history(session_id: str):
    """Retrieve recent conversation messages for a session."""

    key = get_session_key(session_id)

    messages = redis_client.lrange(key, 0, -1)

    return [json.loads(message) for message in messages]


def clear_session(session_id: str):
    """Delete conversation history for a session."""

    key = get_session_key(session_id)

    redis_client.delete(key)


def test_redis_connection():
    """Check whether Redis is reachable."""

    return redis_client.ping()


if __name__ == "__main__":

    print("Testing Redis connection...")

    if test_redis_connection():
        print("Redis connected successfully!")

    test_session = "TEST_SESSION_001"

    add_message(
        test_session,
        "user",
        "What is the weather like in Jaipur?"
    )

    add_message(
        test_session,
        "assistant",
        "I can help you check the Jaipur weather."
    )

    print("\nConversation history:")

    history = get_recent_history(test_session)

    for message in history:
        print(message)

    clear_session(test_session)

    print("\nTest conversation cleared.")
