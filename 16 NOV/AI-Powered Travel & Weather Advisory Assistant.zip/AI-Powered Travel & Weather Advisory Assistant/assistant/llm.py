
from langchain_ollama import ChatOllama


def get_llm():
    """
    Initialize Qwen 3.5:4B using Ollama.
    """

    llm = ChatOllama(
        model="qwen3.5:4b",
        temperature=0.3
    )

    return llm


if __name__ == "__main__":

    llm = get_llm()

    response = llm.invoke(
        "You are a business travel assistant. "
        "Give me three packing suggestions "
        "for a business trip to Jaipur."
    )

    print("\nQwen Model Response:\n")
    print(response.content)
