
import requests
from datetime import date, timedelta
from langchain_core.tools import tool


GEOCODING_URL = "https://geocoding-api.open-meteo.com/v1/search"

FORECAST_URL = "https://api.open-meteo.com/v1/forecast"


def resolve_location(city: str):
    """
    Resolve a city name into latitude and longitude.
    """

    params = {
        "name": city,
        "count": 1,
        "language": "en",
        "format": "json"
    }

    try:
        response = requests.get(
            GEOCODING_URL,
            params=params,
            timeout=15
        )

        response.raise_for_status()

        data = response.json()

        if not data.get("results"):
            return {
                "error": f"Location not found: {city}"
            }

        location = data["results"][0]

        return {
            "name": location["name"],
            "country": location.get("country"),
            "latitude": location["latitude"],
            "longitude": location["longitude"]
        }

    except requests.RequestException as e:
        return {
            "error": f"Geocoding API failed: {str(e)}"
        }


def fetch_weather_forecast(
    city: str,
    start_date: str,
    end_date: str
):
    """
    Retrieve actual weather forecast for a destination.
    """

    try:
        start = date.fromisoformat(start_date)
        end = date.fromisoformat(end_date)

        today = date.today()
        last_supported_date = today + timedelta(days=15)

        if start < today:
            return {
                "error": "Past forecast dates are not supported."
            }

        if end < start:
            return {
                "error": "End date cannot be before start date."
            }

        if end > last_supported_date:
            return {
                "error": (
                    "Requested dates exceed the available "
                    "16-day forecast horizon."
                )
            }

    except ValueError:
        return {
            "error": "Invalid date format. Use YYYY-MM-DD."
        }

    # Resolve city coordinates
    location = resolve_location(city)

    if "error" in location:
        return location

    params = {
        "latitude": location["latitude"],
        "longitude": location["longitude"],
        "daily": [
            "temperature_2m_max",
            "temperature_2m_min",
            "precipitation_sum",
            "weather_code"
        ],
        "start_date": start_date,
        "end_date": end_date,
        "timezone": "auto"
    }

    try:
        response = requests.get(
            FORECAST_URL,
            params=params,
            timeout=20
        )

        response.raise_for_status()

        data = response.json()

        if "daily" not in data:
            return {
                "error": "Weather forecast data is unavailable."
            }

        daily = data["daily"]

        forecasts = []

        for i, forecast_date in enumerate(daily["time"]):

            forecasts.append({
                "date": forecast_date,
                "temperature_max": daily[
                    "temperature_2m_max"
                ][i],
                "temperature_min": daily[
                    "temperature_2m_min"
                ][i],
                "precipitation": daily[
                    "precipitation_sum"
                ][i],
                "weather_code": daily[
                    "weather_code"
                ][i]
            })

        return {
            "location": location["name"],
            "country": location["country"],
            "forecast": forecasts,
            "temperature_unit": data["daily_units"][
                "temperature_2m_max"
            ],
            "precipitation_unit": data["daily_units"][
                "precipitation_sum"
            ]
        }

    except requests.RequestException as e:
        return {
            "error": f"Weather API failed: {str(e)}"
        }


@tool
def weather_tool(
    city: str,
    start_date: str,
    end_date: str
) -> dict:
    """
    Get actual weather forecast for a city and travel dates.
    Returns maximum and minimum temperature, precipitation,
    and weather codes for each available forecast day.
    Dates must be in YYYY-MM-DD format.
    """

    return fetch_weather_forecast(
        city,
        start_date,
        end_date
    )
